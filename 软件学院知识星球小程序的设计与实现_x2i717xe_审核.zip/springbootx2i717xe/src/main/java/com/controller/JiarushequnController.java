package com.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.*;
import java.lang.*;
import java.math.*;
import java.util.stream.Collectors;
import javax.servlet.http.HttpServletRequest;
import com.utils.ValidatorUtils;
import com.utils.DeSensUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.annotation.IgnoreAuth;

import com.entity.JiarushequnEntity;
import com.entity.view.JiarushequnView;

import com.service.JiarushequnService;
import com.service.TokenService;
import com.utils.PageUtils;
import com.utils.R;
import com.utils.MPUtil;
import com.utils.MapUtils;
import com.utils.CommonUtil;
import java.io.IOException;

/**
 * 加入社群
 * 后端接口
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
@RestController
@RequestMapping("/jiarushequn")
public class JiarushequnController {
    @Autowired
    private JiarushequnService jiarushequnService;






    



    /**
     * 后台列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params,JiarushequnEntity jiarushequn,
		HttpServletRequest request){
		String tableName = request.getSession().getAttribute("tableName").toString();
		if(tableName.equals("chuangzuozhe")) {
			jiarushequn.setChuangzuozhanghao((String)request.getSession().getAttribute("username"));
		}
		if(tableName.equals("yonghu")) {
			jiarushequn.setZhanghao((String)request.getSession().getAttribute("username"));
		}
        //设置查询条件
        EntityWrapper<JiarushequnEntity> ew = new EntityWrapper<JiarushequnEntity>();


        //查询结果
		PageUtils page = jiarushequnService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, jiarushequn), params), params));
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(page,deSens);
        return R.ok().put("data", page);
    }
    
    /**
     * 前台列表
     */
	@IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params,JiarushequnEntity jiarushequn, 
		HttpServletRequest request){
        //设置查询条件
        EntityWrapper<JiarushequnEntity> ew = new EntityWrapper<JiarushequnEntity>();

        //查询结果
		PageUtils page = jiarushequnService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, jiarushequn), params), params));
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(page,deSens);
        return R.ok().put("data", page);
    }



	/**
     * 列表
     */
    @RequestMapping("/lists")
    public R list( JiarushequnEntity jiarushequn){
       	EntityWrapper<JiarushequnEntity> ew = new EntityWrapper<JiarushequnEntity>();
      	ew.allEq(MPUtil.allEQMapPre( jiarushequn, "jiarushequn")); 
        return R.ok().put("data", jiarushequnService.selectListView(ew));
    }

	 /**
     * 查询
     */
    @RequestMapping("/query")
    public R query(JiarushequnEntity jiarushequn){
        EntityWrapper< JiarushequnEntity> ew = new EntityWrapper< JiarushequnEntity>();
 		ew.allEq(MPUtil.allEQMapPre( jiarushequn, "jiarushequn")); 
		JiarushequnView jiarushequnView =  jiarushequnService.selectView(ew);
		return R.ok("查询加入社群成功").put("data", jiarushequnView);
    }
	
    /**
     * 后台详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id){
        JiarushequnEntity jiarushequn = jiarushequnService.selectById(id);
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(jiarushequn,deSens);
        return R.ok().put("data", jiarushequn);
    }

    /**
     * 前台详情
     */
	@IgnoreAuth
    @RequestMapping("/detail/{id}")
    public R detail(@PathVariable("id") Long id){
        JiarushequnEntity jiarushequn = jiarushequnService.selectById(id);
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(jiarushequn,deSens);
        return R.ok().put("data", jiarushequn);
    }
    



    /**
     * 后台保存
     */
    @RequestMapping("/save")
    public R save(@RequestBody JiarushequnEntity jiarushequn, HttpServletRequest request){
        //ValidatorUtils.validateEntity(jiarushequn);
        jiarushequnService.insert(jiarushequn);
        return R.ok().put("data",jiarushequn.getId());
    }
    
    /**
     * 前台保存
     */
    @RequestMapping("/add")
    public R add(@RequestBody JiarushequnEntity jiarushequn, HttpServletRequest request){
        //ValidatorUtils.validateEntity(jiarushequn);
        jiarushequnService.insert(jiarushequn);
        return R.ok().put("data",jiarushequn.getId());
    }





    /**
     * 修改
     */
    @RequestMapping("/update")
    @Transactional
    public R update(@RequestBody JiarushequnEntity jiarushequn, HttpServletRequest request){
        //ValidatorUtils.validateEntity(jiarushequn);
        //全部更新
        jiarushequnService.updateById(jiarushequn);
        return R.ok();
    }

    /**
     * 审核
     */
    @RequestMapping("/shBatch")
    @Transactional
    public R update(@RequestBody Long[] ids, @RequestParam String sfsh, @RequestParam String shhf){
        List<JiarushequnEntity> list = new ArrayList<JiarushequnEntity>();
        for(Long id : ids) {
            JiarushequnEntity jiarushequn = jiarushequnService.selectById(id);
            jiarushequn.setSfsh(sfsh);
            jiarushequn.setShhf(shhf);
            list.add(jiarushequn);
        }
        jiarushequnService.updateBatchById(list);
        return R.ok();
    }


    

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Long[] ids){
        jiarushequnService.deleteBatchIds(Arrays.asList(ids));
        return R.ok();
    }
    








}
