package com.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.*;
import java.lang.*;
import java.math.*;
import java.util.stream.Collectors;
import javax.servlet.http.HttpServletRequest;
import com.utils.ValidatorUtils;
import com.utils.DeSensUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.annotation.IgnoreAuth;

import com.entity.ShequngonggaoEntity;
import com.entity.view.ShequngonggaoView;

import com.service.ShequngonggaoService;
import com.service.TokenService;
import com.utils.PageUtils;
import com.utils.R;
import com.utils.MPUtil;
import com.utils.MapUtils;
import com.utils.CommonUtil;
import java.io.IOException;

/**
 * 社群公告
 * 后端接口
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
@RestController
@RequestMapping("/shequngonggao")
public class ShequngonggaoController {
    @Autowired
    private ShequngonggaoService shequngonggaoService;






    



    /**
     * 后台列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params,ShequngonggaoEntity shequngonggao,
		HttpServletRequest request){
		String tableName = request.getSession().getAttribute("tableName").toString();
		if(tableName.equals("chuangzuozhe")) {
			shequngonggao.setChuangzuozhanghao((String)request.getSession().getAttribute("username"));
		}
        //设置查询条件
        EntityWrapper<ShequngonggaoEntity> ew = new EntityWrapper<ShequngonggaoEntity>();


        //查询结果
		PageUtils page = shequngonggaoService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, shequngonggao), params), params));
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(page,deSens);
        return R.ok().put("data", page);
    }
    
    /**
     * 前台列表
     */
	@IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params,ShequngonggaoEntity shequngonggao, 
		HttpServletRequest request){
        //设置查询条件
        EntityWrapper<ShequngonggaoEntity> ew = new EntityWrapper<ShequngonggaoEntity>();

        //查询结果
		PageUtils page = shequngonggaoService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, shequngonggao), params), params));
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(page,deSens);
        return R.ok().put("data", page);
    }



	/**
     * 列表
     */
    @RequestMapping("/lists")
    public R list( ShequngonggaoEntity shequngonggao){
       	EntityWrapper<ShequngonggaoEntity> ew = new EntityWrapper<ShequngonggaoEntity>();
      	ew.allEq(MPUtil.allEQMapPre( shequngonggao, "shequngonggao")); 
        return R.ok().put("data", shequngonggaoService.selectListView(ew));
    }

	 /**
     * 查询
     */
    @RequestMapping("/query")
    public R query(ShequngonggaoEntity shequngonggao){
        EntityWrapper< ShequngonggaoEntity> ew = new EntityWrapper< ShequngonggaoEntity>();
 		ew.allEq(MPUtil.allEQMapPre( shequngonggao, "shequngonggao")); 
		ShequngonggaoView shequngonggaoView =  shequngonggaoService.selectView(ew);
		return R.ok("查询社群公告成功").put("data", shequngonggaoView);
    }
	
    /**
     * 后台详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id){
        ShequngonggaoEntity shequngonggao = shequngonggaoService.selectById(id);
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(shequngonggao,deSens);
        return R.ok().put("data", shequngonggao);
    }

    /**
     * 前台详情
     */
	@IgnoreAuth
    @RequestMapping("/detail/{id}")
    public R detail(@PathVariable("id") Long id){
        ShequngonggaoEntity shequngonggao = shequngonggaoService.selectById(id);
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(shequngonggao,deSens);
        return R.ok().put("data", shequngonggao);
    }
    



    /**
     * 后台保存
     */
    @RequestMapping("/save")
    public R save(@RequestBody ShequngonggaoEntity shequngonggao, HttpServletRequest request){
        //ValidatorUtils.validateEntity(shequngonggao);
        shequngonggaoService.insert(shequngonggao);
        return R.ok().put("data",shequngonggao.getId());
    }
    
    /**
     * 前台保存
     */
    @RequestMapping("/add")
    public R add(@RequestBody ShequngonggaoEntity shequngonggao, HttpServletRequest request){
        //ValidatorUtils.validateEntity(shequngonggao);
        shequngonggaoService.insert(shequngonggao);
        return R.ok().put("data",shequngonggao.getId());
    }





    /**
     * 修改
     */
    @RequestMapping("/update")
    @Transactional
    public R update(@RequestBody ShequngonggaoEntity shequngonggao, HttpServletRequest request){
        //ValidatorUtils.validateEntity(shequngonggao);
        //全部更新
        shequngonggaoService.updateById(shequngonggao);
        return R.ok();
    }



    

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Long[] ids){
        shequngonggaoService.deleteBatchIds(Arrays.asList(ids));
        return R.ok();
    }
    








}
