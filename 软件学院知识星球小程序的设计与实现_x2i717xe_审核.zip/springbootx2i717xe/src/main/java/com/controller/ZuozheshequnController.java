package com.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.*;
import java.lang.*;
import java.math.*;
import java.util.stream.Collectors;
import javax.servlet.http.HttpServletRequest;
import com.utils.ValidatorUtils;
import com.utils.DeSensUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.annotation.IgnoreAuth;

import com.entity.ZuozheshequnEntity;
import com.entity.view.ZuozheshequnView;

import com.service.ZuozheshequnService;
import com.service.TokenService;
import com.utils.PageUtils;
import com.utils.R;
import com.utils.MPUtil;
import com.utils.MapUtils;
import com.utils.CommonUtil;
import java.io.IOException;

/**
 * 作者社群
 * 后端接口
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
@RestController
@RequestMapping("/zuozheshequn")
public class ZuozheshequnController {
    @Autowired
    private ZuozheshequnService zuozheshequnService;






    



    /**
     * 后台列表
     */
    @RequestMapping("/page")
    public R page(@RequestParam Map<String, Object> params,ZuozheshequnEntity zuozheshequn,
		HttpServletRequest request){
		String tableName = request.getSession().getAttribute("tableName").toString();
		if(tableName.equals("chuangzuozhe")) {
			zuozheshequn.setChuangzuozhanghao((String)request.getSession().getAttribute("username"));
		}
        //设置查询条件
        EntityWrapper<ZuozheshequnEntity> ew = new EntityWrapper<ZuozheshequnEntity>();


        //查询结果
		PageUtils page = zuozheshequnService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, zuozheshequn), params), params));
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(page,deSens);
        return R.ok().put("data", page);
    }
    
    /**
     * 前台列表
     */
	@IgnoreAuth
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params,ZuozheshequnEntity zuozheshequn, 
		HttpServletRequest request){
        //设置查询条件
        EntityWrapper<ZuozheshequnEntity> ew = new EntityWrapper<ZuozheshequnEntity>();

        //查询结果
		PageUtils page = zuozheshequnService.queryPage(params, MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, zuozheshequn), params), params));
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(page,deSens);
        return R.ok().put("data", page);
    }



	/**
     * 列表
     */
    @RequestMapping("/lists")
    public R list( ZuozheshequnEntity zuozheshequn){
       	EntityWrapper<ZuozheshequnEntity> ew = new EntityWrapper<ZuozheshequnEntity>();
      	ew.allEq(MPUtil.allEQMapPre( zuozheshequn, "zuozheshequn")); 
        return R.ok().put("data", zuozheshequnService.selectListView(ew));
    }

	 /**
     * 查询
     */
    @RequestMapping("/query")
    public R query(ZuozheshequnEntity zuozheshequn){
        EntityWrapper< ZuozheshequnEntity> ew = new EntityWrapper< ZuozheshequnEntity>();
 		ew.allEq(MPUtil.allEQMapPre( zuozheshequn, "zuozheshequn")); 
		ZuozheshequnView zuozheshequnView =  zuozheshequnService.selectView(ew);
		return R.ok("查询作者社群成功").put("data", zuozheshequnView);
    }
	
    /**
     * 后台详情
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Long id){
        ZuozheshequnEntity zuozheshequn = zuozheshequnService.selectById(id);
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(zuozheshequn,deSens);
        return R.ok().put("data", zuozheshequn);
    }

    /**
     * 前台详情
     */
	@IgnoreAuth
    @RequestMapping("/detail/{id}")
    public R detail(@PathVariable("id") Long id){
        ZuozheshequnEntity zuozheshequn = zuozheshequnService.selectById(id);
        Map<String, String> deSens = new HashMap<>();
        //给需要脱敏的字段脱敏
        DeSensUtil.desensitize(zuozheshequn,deSens);
        return R.ok().put("data", zuozheshequn);
    }
    



    /**
     * 后台保存
     */
    @RequestMapping("/save")
    public R save(@RequestBody ZuozheshequnEntity zuozheshequn, HttpServletRequest request){
        //ValidatorUtils.validateEntity(zuozheshequn);
        zuozheshequnService.insert(zuozheshequn);
        return R.ok().put("data",zuozheshequn.getId());
    }
    
    /**
     * 前台保存
     */
    @RequestMapping("/add")
    public R add(@RequestBody ZuozheshequnEntity zuozheshequn, HttpServletRequest request){
        //ValidatorUtils.validateEntity(zuozheshequn);
        zuozheshequnService.insert(zuozheshequn);
        return R.ok().put("data",zuozheshequn.getId());
    }





    /**
     * 修改
     */
    @RequestMapping("/update")
    @Transactional
    public R update(@RequestBody ZuozheshequnEntity zuozheshequn, HttpServletRequest request){
        //ValidatorUtils.validateEntity(zuozheshequn);
        //全部更新
        zuozheshequnService.updateById(zuozheshequn);
        return R.ok();
    }

    /**
     * 审核
     */
    @RequestMapping("/shBatch")
    @Transactional
    public R update(@RequestBody Long[] ids, @RequestParam String sfsh, @RequestParam String shhf){
        List<ZuozheshequnEntity> list = new ArrayList<ZuozheshequnEntity>();
        for(Long id : ids) {
            ZuozheshequnEntity zuozheshequn = zuozheshequnService.selectById(id);
            zuozheshequn.setSfsh(sfsh);
            zuozheshequn.setShhf(shhf);
            list.add(zuozheshequn);
        }
        zuozheshequnService.updateBatchById(list);
        return R.ok();
    }


    

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Long[] ids){
        zuozheshequnService.deleteBatchIds(Arrays.asList(ids));
        return R.ok();
    }
    







    /**
     * 总数量
     */
    @RequestMapping("/count")
    public R count(@RequestParam Map<String, Object> params,ZuozheshequnEntity zuozheshequn, HttpServletRequest request){
        String tableName = request.getSession().getAttribute("tableName").toString();
        if(tableName.equals("chuangzuozhe")) {
            zuozheshequn.setChuangzuozhanghao((String)request.getSession().getAttribute("username"));
        }
        EntityWrapper<ZuozheshequnEntity> ew = new EntityWrapper<ZuozheshequnEntity>();
        int count = zuozheshequnService.selectCount(MPUtil.sort(MPUtil.between(MPUtil.likeOrEq(ew, zuozheshequn), params), params));
        return R.ok().put("data", count);
    }

}
