package com.dao;

import com.entity.ChuangzuozheEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.ChuangzuozheVO;
import com.entity.view.ChuangzuozheView;


/**
 * 创作者
 * 
 * @author 
 * @email 
 * @date 2025-05-18 11:42:28
 */
public interface ChuangzuozheDao extends BaseMapper<ChuangzuozheEntity> {
	
	List<ChuangzuozheVO> selectListVO(@Param("ew") Wrapper<ChuangzuozheEntity> wrapper);
	
	ChuangzuozheVO selectVO(@Param("ew") Wrapper<ChuangzuozheEntity> wrapper);
	
	List<ChuangzuozheView> selectListView(@Param("ew") Wrapper<ChuangzuozheEntity> wrapper);

	List<ChuangzuozheView> selectListView(Pagination page,@Param("ew") Wrapper<ChuangzuozheEntity> wrapper);

	
	ChuangzuozheView selectView(@Param("ew") Wrapper<ChuangzuozheEntity> wrapper);
	

}
