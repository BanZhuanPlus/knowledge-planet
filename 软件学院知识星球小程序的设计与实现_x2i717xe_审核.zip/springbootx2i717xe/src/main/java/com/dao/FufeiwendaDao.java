package com.dao;

import com.entity.FufeiwendaEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.FufeiwendaVO;
import com.entity.view.FufeiwendaView;


/**
 * 付费问答
 * 
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
public interface FufeiwendaDao extends BaseMapper<FufeiwendaEntity> {
	
	List<FufeiwendaVO> selectListVO(@Param("ew") Wrapper<FufeiwendaEntity> wrapper);
	
	FufeiwendaVO selectVO(@Param("ew") Wrapper<FufeiwendaEntity> wrapper);
	
	List<FufeiwendaView> selectListView(@Param("ew") Wrapper<FufeiwendaEntity> wrapper);

	List<FufeiwendaView> selectListView(Pagination page,@Param("ew") Wrapper<FufeiwendaEntity> wrapper);

	
	FufeiwendaView selectView(@Param("ew") Wrapper<FufeiwendaEntity> wrapper);
	

}
