package com.dao;

import com.entity.JiarushequnEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.JiarushequnVO;
import com.entity.view.JiarushequnView;


/**
 * 加入社群
 * 
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
public interface JiarushequnDao extends BaseMapper<JiarushequnEntity> {
	
	List<JiarushequnVO> selectListVO(@Param("ew") Wrapper<JiarushequnEntity> wrapper);
	
	JiarushequnVO selectVO(@Param("ew") Wrapper<JiarushequnEntity> wrapper);
	
	List<JiarushequnView> selectListView(@Param("ew") Wrapper<JiarushequnEntity> wrapper);

	List<JiarushequnView> selectListView(Pagination page,@Param("ew") Wrapper<JiarushequnEntity> wrapper);

	
	JiarushequnView selectView(@Param("ew") Wrapper<JiarushequnEntity> wrapper);
	

}
