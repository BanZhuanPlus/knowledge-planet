package com.dao;

import com.entity.ShequngonggaoEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.ShequngonggaoVO;
import com.entity.view.ShequngonggaoView;


/**
 * 社群公告
 * 
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
public interface ShequngonggaoDao extends BaseMapper<ShequngonggaoEntity> {
	
	List<ShequngonggaoVO> selectListVO(@Param("ew") Wrapper<ShequngonggaoEntity> wrapper);
	
	ShequngonggaoVO selectVO(@Param("ew") Wrapper<ShequngonggaoEntity> wrapper);
	
	List<ShequngonggaoView> selectListView(@Param("ew") Wrapper<ShequngonggaoEntity> wrapper);

	List<ShequngonggaoView> selectListView(Pagination page,@Param("ew") Wrapper<ShequngonggaoEntity> wrapper);

	
	ShequngonggaoView selectView(@Param("ew") Wrapper<ShequngonggaoEntity> wrapper);
	

}
