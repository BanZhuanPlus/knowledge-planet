package com.dao;

import com.entity.TixianEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.TixianVO;
import com.entity.view.TixianView;


/**
 * 提现
 * 
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
public interface TixianDao extends BaseMapper<TixianEntity> {
	
	List<TixianVO> selectListVO(@Param("ew") Wrapper<TixianEntity> wrapper);
	
	TixianVO selectVO(@Param("ew") Wrapper<TixianEntity> wrapper);
	
	List<TixianView> selectListView(@Param("ew") Wrapper<TixianEntity> wrapper);

	List<TixianView> selectListView(Pagination page,@Param("ew") Wrapper<TixianEntity> wrapper);

	
	TixianView selectView(@Param("ew") Wrapper<TixianEntity> wrapper);
	

}
