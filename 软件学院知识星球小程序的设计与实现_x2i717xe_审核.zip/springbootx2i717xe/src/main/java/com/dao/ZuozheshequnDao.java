package com.dao;

import com.entity.ZuozheshequnEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.ZuozheshequnVO;
import com.entity.view.ZuozheshequnView;


/**
 * 作者社群
 * 
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
public interface ZuozheshequnDao extends BaseMapper<ZuozheshequnEntity> {
	
	List<ZuozheshequnVO> selectListVO(@Param("ew") Wrapper<ZuozheshequnEntity> wrapper);
	
	ZuozheshequnVO selectVO(@Param("ew") Wrapper<ZuozheshequnEntity> wrapper);
	
	List<ZuozheshequnView> selectListView(@Param("ew") Wrapper<ZuozheshequnEntity> wrapper);

	List<ZuozheshequnView> selectListView(Pagination page,@Param("ew") Wrapper<ZuozheshequnEntity> wrapper);

	
	ZuozheshequnView selectView(@Param("ew") Wrapper<ZuozheshequnEntity> wrapper);
	

}
