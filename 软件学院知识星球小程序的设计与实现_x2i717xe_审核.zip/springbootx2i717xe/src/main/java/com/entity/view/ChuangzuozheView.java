package com.entity.view;

import com.entity.ChuangzuozheEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import org.apache.commons.beanutils.BeanUtils;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;

import java.io.Serializable;
import com.utils.EncryptUtil;
 

/**
 * 创作者
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 * @date 2025-05-18 11:42:28
 */
@TableName("chuangzuozhe")
public class ChuangzuozheView  extends ChuangzuozheEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public ChuangzuozheView(){
	}
 
 	public ChuangzuozheView(ChuangzuozheEntity chuangzuozheEntity){
 	try {
			BeanUtils.copyProperties(this, chuangzuozheEntity);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}


}
