package com.entity.view;

import com.entity.JiarushequnEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import org.apache.commons.beanutils.BeanUtils;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;

import java.io.Serializable;
import com.utils.EncryptUtil;
 

/**
 * 加入社群
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
@TableName("jiarushequn")
public class JiarushequnView  extends JiarushequnEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public JiarushequnView(){
	}
 
 	public JiarushequnView(JiarushequnEntity jiarushequnEntity){
 	try {
			BeanUtils.copyProperties(this, jiarushequnEntity);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}


}
