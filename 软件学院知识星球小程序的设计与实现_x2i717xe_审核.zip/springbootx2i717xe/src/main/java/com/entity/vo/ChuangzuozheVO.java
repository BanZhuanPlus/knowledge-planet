package com.entity.vo;

import com.entity.ChuangzuozheEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 创作者
 * @author 
 * @email 
 * @date 2025-05-18 11:42:28
 */
public class ChuangzuozheVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 密码
	 */
	
	private String mima;
		
	/**
	 * 创作姓名
	 */
	
	private String chuangzuoxingming;
		
	/**
	 * 头像
	 */
	
	private String touxiang;
		
	/**
	 * 性别
	 */
	
	private String xingbie;
		
	/**
	 * 创作电话
	 */
	
	private String chuangzuodianhua;
		
	/**
	 * 咨询费用
	 */
	
	private Integer zixunfeiyong;
				
	
	/**
	 * 设置：密码
	 */
	 
	public void setMima(String mima) {
		this.mima = mima;
	}
	
	/**
	 * 获取：密码
	 */
	public String getMima() {
		return mima;
	}
				
	
	/**
	 * 设置：创作姓名
	 */
	 
	public void setChuangzuoxingming(String chuangzuoxingming) {
		this.chuangzuoxingming = chuangzuoxingming;
	}
	
	/**
	 * 获取：创作姓名
	 */
	public String getChuangzuoxingming() {
		return chuangzuoxingming;
	}
				
	
	/**
	 * 设置：头像
	 */
	 
	public void setTouxiang(String touxiang) {
		this.touxiang = touxiang;
	}
	
	/**
	 * 获取：头像
	 */
	public String getTouxiang() {
		return touxiang;
	}
				
	
	/**
	 * 设置：性别
	 */
	 
	public void setXingbie(String xingbie) {
		this.xingbie = xingbie;
	}
	
	/**
	 * 获取：性别
	 */
	public String getXingbie() {
		return xingbie;
	}
				
	
	/**
	 * 设置：创作电话
	 */
	 
	public void setChuangzuodianhua(String chuangzuodianhua) {
		this.chuangzuodianhua = chuangzuodianhua;
	}
	
	/**
	 * 获取：创作电话
	 */
	public String getChuangzuodianhua() {
		return chuangzuodianhua;
	}
				
	
	/**
	 * 设置：咨询费用
	 */
	 
	public void setZixunfeiyong(Integer zixunfeiyong) {
		this.zixunfeiyong = zixunfeiyong;
	}
	
	/**
	 * 获取：咨询费用
	 */
	public Integer getZixunfeiyong() {
		return zixunfeiyong;
	}
			
}
