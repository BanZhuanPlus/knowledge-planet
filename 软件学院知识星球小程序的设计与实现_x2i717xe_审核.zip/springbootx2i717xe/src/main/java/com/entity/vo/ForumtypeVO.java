package com.entity.vo;

import com.entity.ForumtypeEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 论坛类型
 * @author 
 * @email 
 * @date 2025-05-18 11:42:30
 */
public class ForumtypeVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 				
}
