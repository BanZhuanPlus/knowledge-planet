package com.entity.vo;

import com.entity.FufeiwendaEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 付费问答
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
public class FufeiwendaVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 创作账号
	 */
	
	private String chuangzuozhanghao;
		
	/**
	 * 创作姓名
	 */
	
	private String chuangzuoxingming;
		
	/**
	 * 账号
	 */
	
	private String zhanghao;
		
	/**
	 * 姓名
	 */
	
	private String xingming;
		
	/**
	 * 咨询费用
	 */
	
	private Integer zixunfeiyong;
		
	/**
	 * 封面
	 */
	
	private String fengmian;
		
	/**
	 * 咨询问题
	 */
	
	private String zixunwenti;
		
	/**
	 * 备注
	 */
	
	private String beizhu;
		
	/**
	 * 咨询时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date zixunshijian;
		
	/**
	 * 回复内容
	 */
	
	private String shhf;
		
	/**
	 * 是否支付
	 */
	
	private String ispay;
				
	
	/**
	 * 设置：创作账号
	 */
	 
	public void setChuangzuozhanghao(String chuangzuozhanghao) {
		this.chuangzuozhanghao = chuangzuozhanghao;
	}
	
	/**
	 * 获取：创作账号
	 */
	public String getChuangzuozhanghao() {
		return chuangzuozhanghao;
	}
				
	
	/**
	 * 设置：创作姓名
	 */
	 
	public void setChuangzuoxingming(String chuangzuoxingming) {
		this.chuangzuoxingming = chuangzuoxingming;
	}
	
	/**
	 * 获取：创作姓名
	 */
	public String getChuangzuoxingming() {
		return chuangzuoxingming;
	}
				
	
	/**
	 * 设置：账号
	 */
	 
	public void setZhanghao(String zhanghao) {
		this.zhanghao = zhanghao;
	}
	
	/**
	 * 获取：账号
	 */
	public String getZhanghao() {
		return zhanghao;
	}
				
	
	/**
	 * 设置：姓名
	 */
	 
	public void setXingming(String xingming) {
		this.xingming = xingming;
	}
	
	/**
	 * 获取：姓名
	 */
	public String getXingming() {
		return xingming;
	}
				
	
	/**
	 * 设置：咨询费用
	 */
	 
	public void setZixunfeiyong(Integer zixunfeiyong) {
		this.zixunfeiyong = zixunfeiyong;
	}
	
	/**
	 * 获取：咨询费用
	 */
	public Integer getZixunfeiyong() {
		return zixunfeiyong;
	}
				
	
	/**
	 * 设置：封面
	 */
	 
	public void setFengmian(String fengmian) {
		this.fengmian = fengmian;
	}
	
	/**
	 * 获取：封面
	 */
	public String getFengmian() {
		return fengmian;
	}
				
	
	/**
	 * 设置：咨询问题
	 */
	 
	public void setZixunwenti(String zixunwenti) {
		this.zixunwenti = zixunwenti;
	}
	
	/**
	 * 获取：咨询问题
	 */
	public String getZixunwenti() {
		return zixunwenti;
	}
				
	
	/**
	 * 设置：备注
	 */
	 
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
	
	/**
	 * 获取：备注
	 */
	public String getBeizhu() {
		return beizhu;
	}
				
	
	/**
	 * 设置：咨询时间
	 */
	 
	public void setZixunshijian(Date zixunshijian) {
		this.zixunshijian = zixunshijian;
	}
	
	/**
	 * 获取：咨询时间
	 */
	public Date getZixunshijian() {
		return zixunshijian;
	}
				
	
	/**
	 * 设置：回复内容
	 */
	 
	public void setShhf(String shhf) {
		this.shhf = shhf;
	}
	
	/**
	 * 获取：回复内容
	 */
	public String getShhf() {
		return shhf;
	}
				
	
	/**
	 * 设置：是否支付
	 */
	 
	public void setIspay(String ispay) {
		this.ispay = ispay;
	}
	
	/**
	 * 获取：是否支付
	 */
	public String getIspay() {
		return ispay;
	}
			
}
