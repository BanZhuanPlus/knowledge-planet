package com.entity.vo;

import com.entity.JiarushequnEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 加入社群
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
public class JiarushequnVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 加入人数
	 */
	
	private Integer chengyuanshuliang;
		
	/**
	 * 封面
	 */
	
	private String fengmian;
		
	/**
	 * 创作账号
	 */
	
	private String chuangzuozhanghao;
		
	/**
	 * 创作姓名
	 */
	
	private String chuangzuoxingming;
		
	/**
	 * 账号
	 */
	
	private String zhanghao;
		
	/**
	 * 姓名
	 */
	
	private String xingming;
		
	/**
	 * 申请原因
	 */
	
	private String shenqingyuanyin;
		
	/**
	 * 提交时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date tijiaoshijian;
		
	/**
	 * 是否审核
	 */
	
	private String sfsh;
		
	/**
	 * 审核回复
	 */
	
	private String shhf;
				
	
	/**
	 * 设置：加入人数
	 */
	 
	public void setChengyuanshuliang(Integer chengyuanshuliang) {
		this.chengyuanshuliang = chengyuanshuliang;
	}
	
	/**
	 * 获取：加入人数
	 */
	public Integer getChengyuanshuliang() {
		return chengyuanshuliang;
	}
				
	
	/**
	 * 设置：封面
	 */
	 
	public void setFengmian(String fengmian) {
		this.fengmian = fengmian;
	}
	
	/**
	 * 获取：封面
	 */
	public String getFengmian() {
		return fengmian;
	}
				
	
	/**
	 * 设置：创作账号
	 */
	 
	public void setChuangzuozhanghao(String chuangzuozhanghao) {
		this.chuangzuozhanghao = chuangzuozhanghao;
	}
	
	/**
	 * 获取：创作账号
	 */
	public String getChuangzuozhanghao() {
		return chuangzuozhanghao;
	}
				
	
	/**
	 * 设置：创作姓名
	 */
	 
	public void setChuangzuoxingming(String chuangzuoxingming) {
		this.chuangzuoxingming = chuangzuoxingming;
	}
	
	/**
	 * 获取：创作姓名
	 */
	public String getChuangzuoxingming() {
		return chuangzuoxingming;
	}
				
	
	/**
	 * 设置：账号
	 */
	 
	public void setZhanghao(String zhanghao) {
		this.zhanghao = zhanghao;
	}
	
	/**
	 * 获取：账号
	 */
	public String getZhanghao() {
		return zhanghao;
	}
				
	
	/**
	 * 设置：姓名
	 */
	 
	public void setXingming(String xingming) {
		this.xingming = xingming;
	}
	
	/**
	 * 获取：姓名
	 */
	public String getXingming() {
		return xingming;
	}
				
	
	/**
	 * 设置：申请原因
	 */
	 
	public void setShenqingyuanyin(String shenqingyuanyin) {
		this.shenqingyuanyin = shenqingyuanyin;
	}
	
	/**
	 * 获取：申请原因
	 */
	public String getShenqingyuanyin() {
		return shenqingyuanyin;
	}
				
	
	/**
	 * 设置：提交时间
	 */
	 
	public void setTijiaoshijian(Date tijiaoshijian) {
		this.tijiaoshijian = tijiaoshijian;
	}
	
	/**
	 * 获取：提交时间
	 */
	public Date getTijiaoshijian() {
		return tijiaoshijian;
	}
				
	
	/**
	 * 设置：是否审核
	 */
	 
	public void setSfsh(String sfsh) {
		this.sfsh = sfsh;
	}
	
	/**
	 * 获取：是否审核
	 */
	public String getSfsh() {
		return sfsh;
	}
				
	
	/**
	 * 设置：审核回复
	 */
	 
	public void setShhf(String shhf) {
		this.shhf = shhf;
	}
	
	/**
	 * 获取：审核回复
	 */
	public String getShhf() {
		return shhf;
	}
			
}
