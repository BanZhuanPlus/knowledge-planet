package com.entity.vo;

import com.entity.ZhishifenleiEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 知识分类
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
public class ZhishifenleiVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 				
}
