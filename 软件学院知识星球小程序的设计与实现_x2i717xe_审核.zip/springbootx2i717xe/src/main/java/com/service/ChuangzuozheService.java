package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ChuangzuozheEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ChuangzuozheVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ChuangzuozheView;


/**
 * 创作者
 *
 * @author 
 * @email 
 * @date 2025-05-18 11:42:28
 */
public interface ChuangzuozheService extends IService<ChuangzuozheEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ChuangzuozheVO> selectListVO(Wrapper<ChuangzuozheEntity> wrapper);
   	
   	ChuangzuozheVO selectVO(@Param("ew") Wrapper<ChuangzuozheEntity> wrapper);
   	
   	List<ChuangzuozheView> selectListView(Wrapper<ChuangzuozheEntity> wrapper);
   	
   	ChuangzuozheView selectView(@Param("ew") Wrapper<ChuangzuozheEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ChuangzuozheEntity> wrapper);

   	

}

