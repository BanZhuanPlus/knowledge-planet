package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.FufeiwendaEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.FufeiwendaVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.FufeiwendaView;


/**
 * 付费问答
 *
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
public interface FufeiwendaService extends IService<FufeiwendaEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<FufeiwendaVO> selectListVO(Wrapper<FufeiwendaEntity> wrapper);
   	
   	FufeiwendaVO selectVO(@Param("ew") Wrapper<FufeiwendaEntity> wrapper);
   	
   	List<FufeiwendaView> selectListView(Wrapper<FufeiwendaEntity> wrapper);
   	
   	FufeiwendaView selectView(@Param("ew") Wrapper<FufeiwendaEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<FufeiwendaEntity> wrapper);

   	

}

