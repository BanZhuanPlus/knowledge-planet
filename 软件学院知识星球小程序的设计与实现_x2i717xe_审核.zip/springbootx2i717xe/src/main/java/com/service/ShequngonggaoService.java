package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ShequngonggaoEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ShequngonggaoVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ShequngonggaoView;


/**
 * 社群公告
 *
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
public interface ShequngonggaoService extends IService<ShequngonggaoEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ShequngonggaoVO> selectListVO(Wrapper<ShequngonggaoEntity> wrapper);
   	
   	ShequngonggaoVO selectVO(@Param("ew") Wrapper<ShequngonggaoEntity> wrapper);
   	
   	List<ShequngonggaoView> selectListView(Wrapper<ShequngonggaoEntity> wrapper);
   	
   	ShequngonggaoView selectView(@Param("ew") Wrapper<ShequngonggaoEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ShequngonggaoEntity> wrapper);

   	

}

