package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.TixianEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.TixianVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.TixianView;


/**
 * 提现
 *
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
public interface TixianService extends IService<TixianEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<TixianVO> selectListVO(Wrapper<TixianEntity> wrapper);
   	
   	TixianVO selectVO(@Param("ew") Wrapper<TixianEntity> wrapper);
   	
   	List<TixianView> selectListView(Wrapper<TixianEntity> wrapper);
   	
   	TixianView selectView(@Param("ew") Wrapper<TixianEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<TixianEntity> wrapper);

   	

}

