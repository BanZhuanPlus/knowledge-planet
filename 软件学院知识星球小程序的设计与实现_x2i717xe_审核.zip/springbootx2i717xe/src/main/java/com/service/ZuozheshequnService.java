package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ZuozheshequnEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ZuozheshequnVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ZuozheshequnView;


/**
 * 作者社群
 *
 * @author 
 * @email 
 * @date 2025-05-18 11:42:29
 */
public interface ZuozheshequnService extends IService<ZuozheshequnEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ZuozheshequnVO> selectListVO(Wrapper<ZuozheshequnEntity> wrapper);
   	
   	ZuozheshequnVO selectVO(@Param("ew") Wrapper<ZuozheshequnEntity> wrapper);
   	
   	List<ZuozheshequnView> selectListView(Wrapper<ZuozheshequnEntity> wrapper);
   	
   	ZuozheshequnView selectView(@Param("ew") Wrapper<ZuozheshequnEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ZuozheshequnEntity> wrapper);

   	

}

