package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.ChuangzuozheDao;
import com.entity.ChuangzuozheEntity;
import com.service.ChuangzuozheService;
import com.entity.vo.ChuangzuozheVO;
import com.entity.view.ChuangzuozheView;

@Service("chuangzuozheService")
public class ChuangzuozheServiceImpl extends ServiceImpl<ChuangzuozheDao, ChuangzuozheEntity> implements ChuangzuozheService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ChuangzuozheEntity> page = this.selectPage(
                new Query<ChuangzuozheEntity>(params).getPage(),
                new EntityWrapper<ChuangzuozheEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ChuangzuozheEntity> wrapper) {
		  Page<ChuangzuozheView> page =new Query<ChuangzuozheView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}

    
    @Override
	public List<ChuangzuozheVO> selectListVO(Wrapper<ChuangzuozheEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public ChuangzuozheVO selectVO(Wrapper<ChuangzuozheEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<ChuangzuozheView> selectListView(Wrapper<ChuangzuozheEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ChuangzuozheView selectView(Wrapper<ChuangzuozheEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
