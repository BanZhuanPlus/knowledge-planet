package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.FufeiwendaDao;
import com.entity.FufeiwendaEntity;
import com.service.FufeiwendaService;
import com.entity.vo.FufeiwendaVO;
import com.entity.view.FufeiwendaView;

@Service("fufeiwendaService")
public class FufeiwendaServiceImpl extends ServiceImpl<FufeiwendaDao, FufeiwendaEntity> implements FufeiwendaService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<FufeiwendaEntity> page = this.selectPage(
                new Query<FufeiwendaEntity>(params).getPage(),
                new EntityWrapper<FufeiwendaEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<FufeiwendaEntity> wrapper) {
		  Page<FufeiwendaView> page =new Query<FufeiwendaView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}

    
    @Override
	public List<FufeiwendaVO> selectListVO(Wrapper<FufeiwendaEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public FufeiwendaVO selectVO(Wrapper<FufeiwendaEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<FufeiwendaView> selectListView(Wrapper<FufeiwendaEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public FufeiwendaView selectView(Wrapper<FufeiwendaEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
