package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.JiarushequnDao;
import com.entity.JiarushequnEntity;
import com.service.JiarushequnService;
import com.entity.vo.JiarushequnVO;
import com.entity.view.JiarushequnView;

@Service("jiarushequnService")
public class JiarushequnServiceImpl extends ServiceImpl<JiarushequnDao, JiarushequnEntity> implements JiarushequnService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<JiarushequnEntity> page = this.selectPage(
                new Query<JiarushequnEntity>(params).getPage(),
                new EntityWrapper<JiarushequnEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<JiarushequnEntity> wrapper) {
		  Page<JiarushequnView> page =new Query<JiarushequnView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}

    
    @Override
	public List<JiarushequnVO> selectListVO(Wrapper<JiarushequnEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public JiarushequnVO selectVO(Wrapper<JiarushequnEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<JiarushequnView> selectListView(Wrapper<JiarushequnEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public JiarushequnView selectView(Wrapper<JiarushequnEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
