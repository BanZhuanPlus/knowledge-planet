package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.ShequngonggaoDao;
import com.entity.ShequngonggaoEntity;
import com.service.ShequngonggaoService;
import com.entity.vo.ShequngonggaoVO;
import com.entity.view.ShequngonggaoView;

@Service("shequngonggaoService")
public class ShequngonggaoServiceImpl extends ServiceImpl<ShequngonggaoDao, ShequngonggaoEntity> implements ShequngonggaoService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ShequngonggaoEntity> page = this.selectPage(
                new Query<ShequngonggaoEntity>(params).getPage(),
                new EntityWrapper<ShequngonggaoEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ShequngonggaoEntity> wrapper) {
		  Page<ShequngonggaoView> page =new Query<ShequngonggaoView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}

    
    @Override
	public List<ShequngonggaoVO> selectListVO(Wrapper<ShequngonggaoEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public ShequngonggaoVO selectVO(Wrapper<ShequngonggaoEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<ShequngonggaoView> selectListView(Wrapper<ShequngonggaoEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ShequngonggaoView selectView(Wrapper<ShequngonggaoEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
