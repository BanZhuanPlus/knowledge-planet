package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.TixianDao;
import com.entity.TixianEntity;
import com.service.TixianService;
import com.entity.vo.TixianVO;
import com.entity.view.TixianView;

@Service("tixianService")
public class TixianServiceImpl extends ServiceImpl<TixianDao, TixianEntity> implements TixianService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<TixianEntity> page = this.selectPage(
                new Query<TixianEntity>(params).getPage(),
                new EntityWrapper<TixianEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<TixianEntity> wrapper) {
		  Page<TixianView> page =new Query<TixianView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}

    
    @Override
	public List<TixianVO> selectListVO(Wrapper<TixianEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public TixianVO selectVO(Wrapper<TixianEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<TixianView> selectListView(Wrapper<TixianEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public TixianView selectView(Wrapper<TixianEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
