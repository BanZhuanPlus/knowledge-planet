package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.ZuozheshequnDao;
import com.entity.ZuozheshequnEntity;
import com.service.ZuozheshequnService;
import com.entity.vo.ZuozheshequnVO;
import com.entity.view.ZuozheshequnView;

@Service("zuozheshequnService")
public class ZuozheshequnServiceImpl extends ServiceImpl<ZuozheshequnDao, ZuozheshequnEntity> implements ZuozheshequnService {
	
	
    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ZuozheshequnEntity> page = this.selectPage(
                new Query<ZuozheshequnEntity>(params).getPage(),
                new EntityWrapper<ZuozheshequnEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ZuozheshequnEntity> wrapper) {
		  Page<ZuozheshequnView> page =new Query<ZuozheshequnView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}

    
    @Override
	public List<ZuozheshequnVO> selectListVO(Wrapper<ZuozheshequnEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public ZuozheshequnVO selectVO(Wrapper<ZuozheshequnEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<ZuozheshequnView> selectListView(Wrapper<ZuozheshequnEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ZuozheshequnView selectView(Wrapper<ZuozheshequnEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
