﻿const base = {
    url : "http://localhost:8080/springbootx2i717xe/"
}
export default base
